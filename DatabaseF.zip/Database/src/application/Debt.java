package application;

public class Debt {
private String Debt;

public String getDebt() {
	return Debt;
}

public void setDebt(String debt) {
	Debt = debt;
}

public Debt(String debt) {
	super();
	Debt = debt;
}
}