package application;

public class Customer {
	private String cid;
	private String passward;
	private String c_name;
	private String address;
	private String hasPremuim;
	private String debt;
	public Customer(String cid, String passward, String c_name, String address, String hasPremuim,String debt) {
		super();
		this.cid = cid;
		this.passward = passward;
		this.c_name = c_name;
		this.address = address;
		this.hasPremuim = hasPremuim;
		this.debt=debt;
	}
	public Customer(String cid,String c_name,String debt) {
		super();
		this.cid = cid;
		this.c_name = c_name;
		this.debt=debt;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getPassward() {
		return passward;
	}
	public void setPassward(String passward) {
		this.passward = passward;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getHasPremuim() {
		return hasPremuim;
	}
	public void setHasPremuim(String hasPremuim) {
		this.hasPremuim = hasPremuim;
	}

	public String getDebt() {
		return debt;
	}
	public void setDebt(String debt) {
		this.debt = debt;
	}
	
	

}
