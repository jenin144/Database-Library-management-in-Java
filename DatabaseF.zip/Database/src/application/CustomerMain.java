package application;

import java.io.IOException;
import java.net.URL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class CustomerMain implements Initializable{
	    @FXML
        private TableView<Book> bookTable;
	    @FXML
	    private TableColumn<Book, String> col_bid;

	    @FXML
	    private TableColumn<Book, String> col_auther;

	    @FXML
	    private TableColumn<Book, String> col_title;

	    @FXML
	    private TableColumn<Book, String> col_edition;

	    @FXML
	    private TableColumn<Book, String> col_scetionname;
	    
	    @FXML
	    private TableColumn<Book, String> col_yearOfBook;


	    @FXML
	    private TableColumn<Book, String> col_standardPremuim;
	    
	    @FXML
	    private TableColumn<Book, String> col_NumOFcopiesAvilable;

	    @FXML
	    private TextField seachField;

	    @FXML
	    private TextField id;

	    @FXML
	    private TextField auther;

	    @FXML
	    private TextField title;

	    @FXML
	    private TextField edi;

	    @FXML
	    private TextField year;

	    @FXML
	    private TextField sect;

	    @FXML
	    private TextField stp;
	    
	   

	    @FXML
	    private TextField startDateBorrow;
	    
	    @FXML
	    private TextField NumOFcopiesAvilableText;
	    
	    @FXML
	    private DatePicker borrowDate;
	    @FXML
	    private TextField return_bookid;

	    @FXML
	    private DatePicker return_date;

	    @FXML
	    private DatePicker DateBorrow;

	    @FXML
	    private TableView<MixCustomer> table;
	    @FXML
	    private TableColumn<MixCustomer, String> Name;

	    @FXML
	    private TableColumn<MixCustomer, String> StartDate;

	    @FXML
	    private TableColumn<MixCustomer, String> EndDate;

	    @FXML
	    private Button Data;

	    @FXML
	    private TextField txt;

	    @FXML
	    private Button Dept;
	    @FXML
	    private TextField text;
        static int counter;
	    
	    ObservableList<Book>oblist=FXCollections.observableArrayList();
	    ObservableList<Book>searchlist=FXCollections.observableArrayList();
	    ObservableList<MixCustomer>mixCustomer=FXCollections.observableArrayList();
	    ObservableList<Debt>dept=FXCollections.observableArrayList();
	    
	public void UpdateTable() {

		col_bid.setCellValueFactory(new PropertyValueFactory<>("bid"));
		col_auther.setCellValueFactory(new PropertyValueFactory<>("author"));
		col_title.setCellValueFactory(new PropertyValueFactory<>("title"));
		col_edition.setCellValueFactory(new PropertyValueFactory<>("edition"));
		col_yearOfBook.setCellValueFactory(new PropertyValueFactory<>("releaseYear"));
		col_scetionname.setCellValueFactory(new PropertyValueFactory<>("sectionname"));
		col_standardPremuim.setCellValueFactory(new PropertyValueFactory<>("standardPremuim"));
		col_NumOFcopiesAvilable.setCellValueFactory(new PropertyValueFactory<>("NumOFcopiesAvilable"));
		oblist = Main.getDataBook();
		bookTable.setItems(oblist);
		bookTable.setOnMouseClicked(value -> {
			getSelected();
		});

	}

	public void getSelected() {
		int index = bookTable.getSelectionModel().getSelectedIndex();
		if (index <= -1) {

			return;
		}

		id.setText(col_bid.getCellData(index).toString());
		auther.setText(col_auther.getCellData(index).toString());
		title.setText(col_title.getCellData(index).toString());
		edi.setText(col_edition.getCellData(index).toString());
		year.setText(col_yearOfBook.getCellData(index).toString());
		sect.setText(col_scetionname.getCellData(index).toString());
		stp.setText(col_standardPremuim.getCellData(index).toString());
		NumOFcopiesAvilableText.setText(col_NumOFcopiesAvilable.getCellData(index).toString());

	}

	public void searchBook() {
		col_bid.setCellValueFactory(new PropertyValueFactory<Book, String>("bid"));
		col_auther.setCellValueFactory(new PropertyValueFactory<Book, String>("author"));
		col_title.setCellValueFactory(new PropertyValueFactory<Book, String>("title"));
		col_edition.setCellValueFactory(new PropertyValueFactory<Book, String>("edition"));
		col_yearOfBook.setCellValueFactory(new PropertyValueFactory<Book, String>("releaseYear"));
		col_scetionname.setCellValueFactory(new PropertyValueFactory<Book, String>("sectionname"));
		col_standardPremuim.setCellValueFactory(new PropertyValueFactory<Book, String>("standardPremuim"));
		col_NumOFcopiesAvilable.setCellValueFactory(new PropertyValueFactory<Book, String>("NumOFcopiesAvilable"));
		searchlist = Main.getDataBook();
		bookTable.setItems(searchlist);
		FilteredList<Book> data = new FilteredList<>(searchlist, p -> true);
		seachField.textProperty().addListener((observable, oldValue, newValue) -> {
			data.setPredicate(value -> {
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}
				String lowerCaseFilter = newValue.toLowerCase();
				if (value.getBid().toLowerCase().indexOf(lowerCaseFilter) != -1) {
					return true;
				} else if (value.getAuthor().toLowerCase().indexOf(lowerCaseFilter) != -1) {
					return true;
				} else if (value.getTitle().toLowerCase().indexOf(lowerCaseFilter) != -1) {
					return true;
				} else if (value.getEdition().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;
				else if (value.getReleaseYear().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;
				else if (value.getSectionname().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;
				else if (value.getStandardPremuim().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;
				else if (value.getNumOFcopiesAvilable().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;

				else
					return false; // Does not match.
			});
		});
		SortedList<Book> sortedData = new SortedList<>(data);
		sortedData.comparatorProperty().bind(bookTable.comparatorProperty());
		bookTable.setItems(sortedData);

	}
	
	
	

	
	@FXML
    void return_BookName_and_Start_And_FinshTime(ActionEvent event) {
		return_BookName_and_Start_And_FinshTime();
    }
	  @FXML
	    void returnDebt(ActionEvent event) {
		  return_debt();
	    }
    public void return_BookName_and_Start_And_FinshTime() {
    	try {
    		Connection conn = Main.getConnection();
    		
    		String sql = "select b.title, bo.startDate,bo.endDate from book b ,borrow bo ,customer c where  c.cid=bo.cid and b.bid=bo.bid and c.cid='"+MainInterface.IDText_LogSign+"'";
    		
    		ResultSet st = conn.createStatement().executeQuery(sql);
    		while(st.next()) {
    			String title = st.getString("b.title");
    			String startDate = st.getString("bo.startDate");
    			String endDate = st.getString("bo.endDate");
    			mixCustomer.add(new MixCustomer(title,startDate,endDate));
    		}
    		
    		Name.setCellValueFactory(new PropertyValueFactory<>("Title"));
    		StartDate.setCellValueFactory(new PropertyValueFactory<>("StartDate"));
    		EndDate.setCellValueFactory(new PropertyValueFactory<>("EndDate"));
    		
    		table.setItems(mixCustomer);
    		
    		mixCustomer=FXCollections.observableArrayList();
    	}
    	
    	catch(Exception ex) {
    		JOptionPane.showMessageDialog(null, ex);
    	}
    }
    


    public void return_debt() {
    	try {
    		//text.clear();
    		Connection conn = Main.getConnection();
    		
    		String sql = "select debt from customer c where c.cid='"+MainInterface.IDText_LogSign+"'";
    		ResultSet st = conn.createStatement().executeQuery(sql);
    		while(st.next()) {
    		String dd = st.getString(1);
            text.setText(dd);
    		}
    	
    		
    	}
    	catch(Exception ex) {
    		JOptionPane.showMessageDialog(null, ex);
    	}
    }
	public void Edit() {
		try {
			Connection conn = Main.getConnection();
			String idVal = id.getText();
			String authVal = auther.getText();
			String titVal = title.getText();
			String ediVal = edi.getText();
			String secVal = sect.getText();
			String yearVal = year.getText();
			String stpVal = stp.getText();
			String qantVal = NumOFcopiesAvilableText.getText();
			PreparedStatement pst;
			String sql = "update Book set bid ='" + idVal + "',author ='" + authVal + "',title ='" + titVal
					+ "',edition ='" + ediVal + "',sectionname ='" + secVal + "',releaseYear ='" + yearVal
					+ "',standardPremuim ='" + stpVal + "',NumOFcopiesAvilable ='" + qantVal + "'where bid='" + idVal + "'";
			pst = conn.prepareStatement(sql);
			pst.execute();
			UpdateTable();
			searchBook();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e);
		}

	}

	
	
	
	public void borrowBooks() {
	    try {
	        Connection conn = Main.getConnection();
	        PreparedStatement pst;
	        PreparedStatement pst2;

	        int q = Integer.parseInt(NumOFcopiesAvilableText.getText());
	        if (q > 0) {
	            String sql;
	            String increaseboroownumber = "UPDATE Book SET NumberOFborrow = NumberOFborrow + 1 WHERE bid = ?";
	            DateTimeFormatter formmat1 = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
	            LocalDateTime dt = LocalDateTime.now();
	            String date = formmat1.format(dt);
	            LocalDateTime ldt;
	            String returnDate;

	            if (stp.getText().equalsIgnoreCase("true")) {
	                String premuimC = "select hasPremuim from Customer where cid ='" + MainInterface.IDText_LogSign + "'";
	                
	                ResultSet premuimResult = conn.createStatement().executeQuery(premuimC);

	                if (premuimResult.next()) {
	                     premuimC = premuimResult.getString("hasPremuim");
	                     if (premuimC.equalsIgnoreCase("yes")) {
	                    sql = "insert into Borrow(cid,bid,startDate,endDate)values(?,?,?,?)";
	                    ldt = LocalDateTime.now().plusDays(20); // 20 days for premium
	                    
	                    pst = conn.prepareStatement(sql);
		                pst.setString(1, MainInterface.IDText_LogSign);
		                pst.setString(2, id.getText());
		                pst.setString(3, date);

		                returnDate = formmat1.format(ldt);
		                pst.setString(4, returnDate);

		                pst.execute();

		                pst2 = conn.prepareStatement(increaseboroownumber);
		                pst2.setString(1, id.getText());
		                pst2.execute();
		                
		                
		            

			            int currentNumOFcopiesAvilable = Integer.parseInt(NumOFcopiesAvilableText.getText()) - 1;
			            NumOFcopiesAvilableText.setText(currentNumOFcopiesAvilable + "");
			            Edit();
			            JOptionPane.showMessageDialog(null, "Book borrowed success");
		                
	                } else {
	                	 Alert alert = new Alert(Alert.AlertType.WARNING);
	     	            alert.setContentText("This Is a premuim book and you have standard sucpcription -- try too upgrade your subs");
	     	            alert.show();
	                }

	                }
	            } else {
	                sql = "insert into Borrow(cid,bid,startDate,endDate)values(?,?,?,?)";
	                pst = conn.prepareStatement(sql);

	                pst.setString(1, MainInterface.IDText_LogSign);
	                pst.setString(2, id.getText());
	                pst.setString(3, date);

	                ldt = LocalDateTime.now().plusDays(10); // 10 days for standard
	                returnDate = formmat1.format(ldt);
	                pst.setString(4, returnDate);

	                pst.execute();

	                pst2 = conn.prepareStatement(increaseboroownumber);
	                pst2.setString(1, id.getText());
	                pst2.execute();
	                

		            int currentNumOFcopiesAvilable = Integer.parseInt(NumOFcopiesAvilableText.getText()) - 1;
		            NumOFcopiesAvilableText.setText(currentNumOFcopiesAvilable + "");
		            Edit();
		            JOptionPane.showMessageDialog(null, "Book borrowed success");
	            }

	        } else {
	            Alert alert = new Alert(Alert.AlertType.ERROR);
	            alert.setTitle("ERROR");
	            alert.setContentText("The books finished");
	            alert.show();
	        }
	    } catch (Exception e) {
	        JOptionPane.showMessageDialog(null, e);
	    }
	}


	public void ReturnBook() {
		Connection conn;
		try {
			conn = Main.getConnection();
			PreparedStatement pst;
			String d1=String.valueOf(DateBorrow.getValue());
			String sql1="select endDate from Borrow where cid ='"+MainInterface.IDText_LogSign+"'and bid ='"+return_bookid.getText()+"'and startDate ='" 
							+d1+"'";
			
			String datFromUser=String.valueOf(return_date.getValue());
			String []datFromUserArr=datFromUser.split("-");
			LocalDate bDate=LocalDate.of(Integer.parseInt(datFromUserArr[0]), Integer.parseInt(datFromUserArr[1]),Integer.parseInt(datFromUserArr[2]));
			Statement st = conn.createStatement();
			ResultSet result = st.executeQuery(sql1);
			String end="";
			if(result.next())
				end=result.getString("endDate");
			
			
			String []sql1Arr=end.split("-");
			LocalDate aDate=LocalDate.of(Integer.parseInt(sql1Arr[0]), Integer.parseInt(sql1Arr[1]),Integer.parseInt(sql1Arr[2]));
			
			 String checkPremium = "select standardPremuim from Book  where bid ='" + return_bookid.getText() + "'";
		        ResultSet premiumResult = st.executeQuery(checkPremium);
		        boolean isPremium = false;
		        if (premiumResult.next()) {
		            isPremium = premiumResult.getString("standardPremuim").equalsIgnoreCase("true");
		        }
			
			if(aDate.isBefore(bDate)) {
				 Period period = Period.between(aDate, bDate);
				    int diffY=period.getYears();
				    int diffM=period.getMonths();
				    int diff = period.getDays();
				    int Fine =((360 * diffY) + (30 * diffM) + diff) * (isPremium ? 10 : 5); // 10 for premium, 5 for standard
				    int Debt; 
				    PreparedStatement pstfine;
				    String fordebt = "SELECT debt FROM customer c WHERE c.cid='" + MainInterface.IDText_LogSign + "'";
				    ResultSet d = conn.createStatement().executeQuery(fordebt);

				    if (d.next()) {
				        String dd = d.getString("debt");

					    Debt = Integer.parseInt(dd) + Fine ;
				 String newSql="update Customer set debt ='"+String.valueOf(Debt)+"'where cid ='"+MainInterface.IDText_LogSign+"'";
	    		    pstfine = conn.prepareStatement(newSql);
				    pstfine.execute();
					    
					    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
						alert.setTitle("info");
						alert.setContentText("the Fine is = "+Fine+" $" + "\n" + "you Debt become = " + Debt +"$" );
						alert.show();
					    
				    }

				    else {
				    
				    	 String newSql="update Customer set debt ='"+String.valueOf(Fine)+"'where cid ='"+MainInterface.IDText_LogSign+"'";
			    		    pstfine = conn.prepareStatement(newSql);
						    pstfine.execute();
				    
				    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
					alert.setTitle("info");
					alert.setContentText("the Fine is = "+Fine+" $" + "\n" + "you Debt become = " + Fine );
					alert.show();
				    
				    }				    
				    
				    
			}
			else { 
				Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
				alert.setTitle("info");
				alert.setContentText("there is no any fine ");
				alert.show();
			}
			PreparedStatement pstD;
			
			String sql = "delete from Borrow where cid='"+MainInterface.IDText_LogSign+"'and bid ='"+return_bookid.getText()+"' and startDate='"+
					d1+"'and endDate='"+end+"'";  
	        pstD = conn.prepareStatement(sql);
			
			pstD.execute();
			
			
			String query="select NumOFcopiesAvilable from Book where bid = '"+return_bookid.getText()+"'";
			ResultSet resultQ = st.executeQuery(query);
			String endQ="";
			if(resultQ.next())
				endQ=resultQ.getString("NumOFcopiesAvilable");
			int q=Integer.parseInt(endQ)+1;
			String update="update Book set NumOFcopiesAvilable='"+String.valueOf(q)+"' where bid = '"+return_bookid.getText()+"'";
			pst = conn.prepareStatement(update);
			pst.execute();
			UpdateTable();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e);
		}
		
		
		

	}

	
	

	
	public void back(ActionEvent event) {//.
    	AnchorPane pane;
		try {
			pane = (AnchorPane) FXMLLoader.load(getClass().getResource("MainInterface.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	

	
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		UpdateTable();
		searchBook();

	}

}
