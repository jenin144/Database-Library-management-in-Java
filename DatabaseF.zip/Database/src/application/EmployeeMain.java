package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class EmployeeMain implements Initializable{
	   @FXML
       private TextField idTextRemove;
	    
	    @FXML
	    private TableView<Book> bookTable;

	    @FXML
	    private TableColumn<Book, String> col_bid;

	    @FXML
	    private TableColumn<Book, String> col_auther;

	  
	    @FXML
	    private TableColumn<Book, String> column;

	    @FXML
	    private TableColumn<Book, String> col_edition;

	    @FXML
	    private TableColumn<Book, String> col_yearOfBook;

	    @FXML
	    private TableColumn<Book, String> col_sectionName;

	    @FXML
	    private TableColumn<Book, String> col_standardPremuim;
	    
	    @FXML
	    private TableColumn<Book, String> col_NumOFcopiesAvilable;
	    
	    @FXML
	    private TextField id;

	    @FXML
	    private TextField auther;

	    @FXML
	    private TextField title;

	    @FXML
	    private TextField editionTF;

	    @FXML
	    private TextField publishedyearTF;

	    @FXML
	    private TextField sectionTF;

	    @FXML
	    private TextField premuimTF;
	    @FXML
	    private TextField searchField;
	    
	    @FXML
	    private TextField NumOFcopiesAvilableTextField;
	    
	    @FXML
	    private DatePicker certainDate;
        
	    @FXML
	    private DatePicker toDate;
	    
	    @FXML
	    private ListView<String> bookNames;
	    
	    @FXML
	    private DatePicker fromDate;

	    @FXML
	    private ListView<String> bookNames1;

	    @FXML
	    private DatePicker toDate2;
        
	    @FXML
	    private TableView<Customer> custTable;

	    @FXML
	    private TableColumn<Customer, String> cid_col;

	    @FXML
	    private TableColumn<Customer, String> c_name_col;

	    @FXML
	    private TableColumn<Customer, String> debt_col;

	    @FXML
	    private PieChart debtChart;
	    @FXML
	    private TableView<MixClass> tableV;

	    @FXML
	    private TableColumn<MixClass, String> col_NameMix;

	    @FXML
	    private TableColumn<MixClass, String> col_IdMix;

	    @FXML
	    private TableColumn<MixClass, String> col_SMix;

	    @FXML
	    private TableColumn<MixClass, String> col_eMix;
	    
	    ////////
	    @FXML
	    private TableView<Book> Mostbb;

	    @FXML
	    private TableColumn<Book, String> bid_col;

	    @FXML
	    private TableColumn<Book, String> bname_col;

	    @FXML
	    private TableColumn<Book, String> numberof_col;

	    
	    
	    
	    @FXML
	    private TableView<MixClass> tableCust;

	    @FXML
	    private TableColumn<MixClass, String> col_Name;
	    
	    @FXML
	    private TableColumn<MixClass, String> col_title;

	    @FXML
	    private TableColumn<MixClass, String> col_bDate;

	    @FXML
	    private TableColumn<MixClass, String> col_rDate;


	    
	    ObservableList <Book>oblist=FXCollections.observableArrayList();
	
	    ObservableList <Book>searchlist;
	     
	    ObservableList<MixClass>booksName=FXCollections.observableArrayList();
	    ObservableList<MixClass>booksName2=FXCollections.observableArrayList();

   
	public void addBook() { //.

		try {
			Connection conn = Main.getConnection();
			PreparedStatement pst;
			

			String sql = "insert into Book SET bid= ?, author= ?,title= ?,edition= ?,releaseYear= ?,sectionname= ?,standardPremuim= ?,NumOFcopiesAvilable= ?";

			pst = conn.prepareStatement(sql);
			pst.setString(1, id.getText());
			pst.setString(2, auther.getText());
			pst.setString(3, title.getText());
			pst.setString(4, editionTF.getText());
			pst.setString(5, publishedyearTF.getText());
			pst.setString(6, sectionTF.getText());
			pst.setString(7, premuimTF.getText());
			pst.setString(8, NumOFcopiesAvilableTextField.getText());

			pst.execute();
			
			//update the table after adding the book
			UpdateTable();
			searchBook();
			JOptionPane.showMessageDialog(null, "The book has been added successfully");
			conn.close();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}

	}
	

	public void deleteBook() { //.
		Connection conn;
		try {
			conn = Main.getConnection();
			PreparedStatement pst;
			String sql = "delete from Book where bid=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, id.getText());
			pst.execute();
			UpdateTable();
			searchBook();
			JOptionPane.showMessageDialog(null, "The book has been deleted successfully");

			conn.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e);
		}

	}

	public void getSelected() {
		//save the index of the selected row 
		int index = bookTable.getSelectionModel().getSelectedIndex();
		if (index <= -1) {

			return;
		}

		id.setText(col_bid.getCellData(index).toString());
		auther.setText(col_auther.getCellData(index).toString());
		title.setText(column.getCellData(index).toString());
		editionTF.setText(col_edition.getCellData(index).toString());
		publishedyearTF.setText(col_yearOfBook.getCellData(index).toString());
		sectionTF.setText(col_sectionName.getCellData(index).toString());
		premuimTF.setText(col_standardPremuim.getCellData(index).toString());
		NumOFcopiesAvilableTextField.setText(col_NumOFcopiesAvilable.getCellData(index).toString());

	}

	
	public void UpdateTable() {

		col_bid.setCellValueFactory(new PropertyValueFactory<>("bid"));
		col_auther.setCellValueFactory(new PropertyValueFactory<>("author"));
		col_edition.setCellValueFactory(new PropertyValueFactory<>("edition"));
		col_yearOfBook.setCellValueFactory(new PropertyValueFactory<>("releaseYear"));
		col_sectionName.setCellValueFactory(new PropertyValueFactory<>("sectionname"));
		col_standardPremuim.setCellValueFactory(new PropertyValueFactory<>("standardPremuim"));
		col_NumOFcopiesAvilable.setCellValueFactory(new PropertyValueFactory<>("NumOFcopiesAvilable"));
		oblist = Main.getDataBook();
		bookTable.setItems(oblist);
		bookTable.setOnMouseClicked(value -> {
			getSelected();
		});

	}

	public void Edit() { //.
		String sql = "update Book set bid =?,author =?,title =?,edition =?,sectionname =?,releaseYear =?,standardPremuim =?,NumOFcopiesAvilable =?where bid=?";

	    try (
		        Connection conn = Main.getConnection();
		        PreparedStatement pst = conn.prepareStatement(sql);
		    ) {
			
	        pst.setString(1, id.getText());
	        pst.setString(2, auther.getText());
	        pst.setString(3, title.getText());
	        pst.setString(4, editionTF.getText());
	        pst.setString(5, sectionTF.getText());
	        pst.setString(6, publishedyearTF.getText());
	        pst.setString(7, premuimTF.getText());
	        pst.setString(8, NumOFcopiesAvilableTextField.getText());
	        pst.setString(9, id.getText());

			
			 pst.executeUpdate();
			   UpdateTable(); // to add the change to the table in the moment of edit
				searchBook();

		        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		        alert.setContentText("Done Editing");
		        alert.show();
		    } catch (SQLException e) {
		        JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
		    } catch (Exception e) {
		        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage());
		    }
		}
	

	

	public void searchBook() {
		col_bid.setCellValueFactory(new PropertyValueFactory<Book, String>("bid"));
		col_auther.setCellValueFactory(new PropertyValueFactory<Book, String>("author"));
		column.setCellValueFactory(new PropertyValueFactory<Book, String>("title"));
		col_edition.setCellValueFactory(new PropertyValueFactory<Book, String>("edition"));
		col_yearOfBook.setCellValueFactory(new PropertyValueFactory<Book, String>("releaseYear"));
		col_sectionName.setCellValueFactory(new PropertyValueFactory<Book, String>("sectionname"));
		col_standardPremuim.setCellValueFactory(new PropertyValueFactory<Book, String>("standardPremuim"));
		col_NumOFcopiesAvilable.setCellValueFactory(new PropertyValueFactory<Book, String>("NumOFcopiesAvilable"));
		searchlist = Main.getDataBook();
		bookTable.setItems(searchlist);
		FilteredList<Book> data = new FilteredList<>(searchlist, p -> true);
		searchField.textProperty().addListener((observable, oldValue, newValue) -> {
			data.setPredicate(value -> {
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}
				String lowerCaseFilter = newValue.toLowerCase();
				if (value.getBid().toLowerCase().indexOf(lowerCaseFilter) != -1) {
					return true;
				} else if (value.getAuthor().toLowerCase().indexOf(lowerCaseFilter) != -1) {
					return true;
				} else if (value.getTitle().toLowerCase().indexOf(lowerCaseFilter) != -1) {
					return true;
				} else if (value.getEdition().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;
				else if (value.getReleaseYear().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;
				else if (value.getSectionname().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;
				else if (value.getStandardPremuim().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;
				else if (value.getNumOFcopiesAvilable().toLowerCase().indexOf(lowerCaseFilter) != -1)
					return true;

				else
					return false; // Does not match.
			});
		});
		SortedList<Book> sortedData = new SortedList<>(data);
		sortedData.comparatorProperty().bind(bookTable.comparatorProperty());
		bookTable.setItems(sortedData);

	}
	
	public void borrowedBooksOutOfDate() {
		Connection conn;
		ObservableList<MixClass> oblist = FXCollections.observableArrayList();
		try {
			conn = Main.getConnection();
			String sql="select c.c_name,B.bid,bo.startDate,bo.endDate from Customer c,Book B,Borrow bo where c.cid=bo.cid and B.bid=bo.bid and bo.startDate < any (select cast(CURRENT_TIMESTAMP () as date)) ";
			ResultSet st = conn.createStatement().executeQuery(sql);
			while (st.next()) {
				String name=st.getString("c.c_name");
				String id =st.getString("B.bid");
				String startDate=st.getString("bo.startDate");
				String endDate=st.getString("bo.endDate");
				oblist.add(new MixClass(name,id,startDate,endDate));

			}

	        tableV.getItems().addAll(oblist);
	        col_NameMix.setCellValueFactory(new PropertyValueFactory<>("c_name"));
	        col_IdMix.setCellValueFactory(new PropertyValueFactory<>("title"));
	        col_SMix.setCellValueFactory(new PropertyValueFactory<>("startDate"));
	        col_eMix.setCellValueFactory(new PropertyValueFactory<>("endDate"));

	    } catch (SQLException e) {
	        e.printStackTrace(); // Handle the exception appropriately
	    }
		
	}
	
	public void debts() {
		try {
			Connection conn = Main.getConnection();
			String sql="select cid ,c_name,debt from Customer where debt > 0";
			ObservableList <Customer>custList=FXCollections.observableArrayList();
			ObservableList<PieChart.Data>pieChart=FXCollections.observableArrayList();
			ResultSet st = conn.createStatement().executeQuery(sql);
			while(st.next()) {
				String cid1=st.getString("cid");
				String c_name1=st.getString("c_name");
				String debt1=st.getString("debt");
			    custList.add(new Customer(cid1,c_name1,debt1));
			    String idPlusName=cid1+" "+c_name1+" ("+debt1+")";
			    pieChart.add(new PieChart.Data(idPlusName,Integer.parseInt(debt1)));
			}
			custTable.setItems(custList);
			cid_col.setCellValueFactory(new PropertyValueFactory<>("cid"));
			c_name_col.setCellValueFactory(new PropertyValueFactory<>("c_name"));
			debt_col.setCellValueFactory(new PropertyValueFactory<>("debt"));
			debtChart.setData(pieChart);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public void back(ActionEvent event) {
    	AnchorPane pane;
		try {
			pane = (AnchorPane) FXMLLoader.load(getClass().getResource("MainInterface.fxml"));

			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e);
		}
    }
	
	
	 public void findMostBorrowedBook() {
	        try {
	            Connection conn = Main.getConnection();
	            PreparedStatement pst;

	            String sql = "SELECT bid, title, NumberOfBorrow " +
	                         "FROM Book " +
	                         "ORDER BY NumberOfBorrow DESC";

	            pst = conn.prepareStatement(sql);
	            ResultSet rs = pst.executeQuery();

	            List<Book> books = new ArrayList<>();

	            while (rs.next()) {
	                String id = rs.getString("bid");
	                String title = rs.getString("title");
	                int numberOfBorrow = rs.getInt("NumberOfBorrow");

	                // Create a Book object
	                Book book = new Book(id, title, numberOfBorrow);

	                // Add the book to the list
	                books.add(book);
	            }

	            Mostbb.getItems().addAll(books);

	            bid_col.setCellValueFactory(new PropertyValueFactory<>("bid"));
	            bname_col.setCellValueFactory(new PropertyValueFactory<>("title"));
	            numberof_col.setCellValueFactory(new PropertyValueFactory<>("numberOfBorrow"));

	        } catch (SQLException e) {
	            e.printStackTrace(); // Handle the exception appropriately
	        }
	    }
	

	
	
////////////////////////	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	    debtChart = new PieChart();

		UpdateTable();

		searchBook();
		
		

	}

}
