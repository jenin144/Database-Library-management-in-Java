package application;



import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class ManagerMain implements Initializable {
//edit	
    @FXML
    private TextField cid2;
    @FXML
    private TextField Name;

    
    
    @FXML
    private TextField eid;
    @FXML
    private TextField firstName;
    @FXML
    private TextField lastName;
    
    
    @FXML
    private TextField eid2;
    @FXML
    private TextField firstName2;
    @FXML
    private TextField lastName2;
    @FXML
    private DatePicker DobTF;
    @FXML
    private TextField phoneNumber;
    @FXML
    private TextField salary;
    @FXML
    private TextField address;
    @FXML
    private PasswordField passward;
    
    ///// signUp
	@FXML
    private TextField IDTF;

    @FXML
    private TextField passTF;

    @FXML
    private TextField fnameTF;

    @FXML
    private TextField lnameTF;

    @FXML
    private DatePicker dobTF;

    @FXML
    private TextField AddressTF;

    @FXML
    private TextField phoneTf;

    @FXML
    private TextField salaryTF;
    
    
    
    @FXML
    private TableView<MixCustomer> table3;
    @FXML
    private TableColumn<MixCustomer, String> Named;

    @FXML
    private TableColumn<MixCustomer, String> StartDate;

    @FXML
    private TableColumn<MixCustomer, String> EndDate;
    ObservableList<MixCustomer>mixCustomer=FXCollections.observableArrayList();

    
    
	public void signUp() {
		try {

			Connection conn = Main.getConnection();
			PreparedStatement pst;

			String sql = "insert into Employee (eid,passward,firstName,lastName,DOB,address,phoneNumber,salary) values(?,?,?,?,?,?,?,? )";

			pst = conn.prepareStatement(sql);
			pst.setString(1, IDTF.getText());
			pst.setString(2, passTF.getText());
			pst.setString(3, fnameTF.getText());
			pst.setString(4, lnameTF.getText());
			String ageVal = String.valueOf(dobTF.getValue());
			pst.setString(5, ageVal);
			pst.setString(6, AddressTF.getText());
			pst.setString(7, phoneTf.getText());
			pst.setString(8, salaryTF.getText());
			

			pst.execute();
			
			// Show a confirmation message
			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setContentText("Employee Added Successfuly");
			alert.show();
			conn.close();

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
		
	}
    
    
   
	   public void EditEmp() {
		    String sql = "UPDATE Employee SET firstName = ?, lastName = ?, DOB = ?, address = ?, phoneNumber = ?, salary = ? WHERE eid = ?";
		    try (
		        Connection conn = Main.getConnection();
		        PreparedStatement pst = conn.prepareStatement(sql);
		    ) {
		        pst.setString(1, firstName.getText());
		        pst.setString(2, lastName.getText());
		        pst.setString(3, String.valueOf(DobTF.getValue()));
		        pst.setString(4, address.getText());
		        pst.setString(5, phoneNumber.getText());
		        pst.setString(6, salary.getText());
		        pst.setString(7, eid.getText());
		        
		        pst.executeUpdate();

		        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		        alert.setContentText("Done Editing");
		        alert.show();
		    } catch (SQLException e) {
		        JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
		    } catch (Exception e) {
		        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage());
		    }
		}

	

	
	
	
    public void back(ActionEvent event) {
    	AnchorPane pane;
		try {
			pane = (AnchorPane) FXMLLoader.load(getClass().getResource("MainInterface.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			  // Show an error dialog to the user
	        Alert alert = new Alert(Alert.AlertType.ERROR);
	        alert.setHeaderText("Cannot Load the Scene");
	        alert.setContentText("There was an error while trying to load the scene: " + e.getMessage());
	        alert.showAndWait();
		}
		
		
		
    }
    
    
    
	public void searchEmployee() {
    
		
		// TODO Auto-generated method stub
		try {
			Connection conn=Main.getConnection();
			String sql="select * from Employee where eid='"+eid.getText()+"'";
			Statement st = conn.createStatement();
			ResultSet autofill = st.executeQuery(sql);
			if(autofill.next()) {
				passward.setText(autofill.getString("passward"));
				firstName.setText(autofill.getString("firstName"));
				lastName.setText(autofill.getString("lastName"));
				address.setText(autofill.getString("address"));
				phoneNumber.setText(autofill.getString("phoneNumber"));
				DobTF.setPromptText(autofill.getString("DOB"));
				salary.setText(autofill.getString("salary"));

			}
			
			else {				
                showAlert("There is no employee with this id");
			}

		} catch (SQLException e) {
	
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
    
	public void searchEmployeefordeleting() {
	    String sql = "SELECT firstName, lastName FROM Employee WHERE eid = ?";
	    try (
	        Connection conn = Main.getConnection();
	        PreparedStatement pst = conn.prepareStatement(sql);
	    ) {
	        pst.setString(1, eid2.getText());
	        try (ResultSet autofill = pst.executeQuery()) {
	            if (autofill.next()) {
	                firstName2.setText(autofill.getString("firstName"));
	                lastName2.setText(autofill.getString("lastName"));
	            } else {
	                firstName2.clear();
	                lastName2.clear();
	                showAlert("There is no employee with this id");
	            }
	        }
	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(null, e);
	    }
	}
	
	private void showAlert(String message) {
	    Alert alert = new Alert(Alert.AlertType.WARNING);
	    alert.setContentText(message);
	    alert.show();
	}

	
	
    public void deleteEmployee() {
        Connection conn;
        try {
            conn = Main.getConnection();
            PreparedStatement pst;
            String sql = "Delete from Employee where eid=?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, eid2.getText());
            pst.execute();

            conn.close();
            
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
			alert.setContentText("The employee has been deleted");
			alert.show();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            JOptionPane.showMessageDialog(null, e);
        }

    }
    
    
    
    
    public void deleteCustomer() {
        Connection conn;
        try {
            conn = Main.getConnection();
            PreparedStatement pst;
            String sql = "delete from customer where cid='"+cid2.getText()+"'";
            pst = conn.prepareStatement(sql);

            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "The Customer has been deleted");
            } else {
                JOptionPane.showMessageDialog(null, "No customer found with this ID");
            }

            conn.close();

        } catch (Exception e) {
            // TODO Auto-generated catch block
        	Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setContentText("This Customer still has book -- return books first and pay the debt ");
			alert.show();
        }

    }
    
	public void searchcstomerfordeleting() {
	    String sql = "SELECT c_name FROM customer WHERE cid = ?";
	    try (
	        Connection conn = Main.getConnection();
	        PreparedStatement pst = conn.prepareStatement(sql);
	    ) {
	        pst.setString(1, cid2.getText());
	        try (ResultSet autofill = pst.executeQuery()) {
	            if (autofill.next()) {
	                Name.setText(autofill.getString("c_name"));
	            } else {

	                showAlert("There is no Customer with this id");
	            }
	        }
	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(null, e);
	    }
	}
    

    public void borrr() {
    	
    	
    	try {
    		Connection conn = Main.getConnection();
    		
    		String sql = "select b.title, bo.startDate,bo.endDate from book b ,borrow bo ,customer c where  c.cid=bo.cid and b.bid=bo.bid and c.cid='"+cid2.getText()+"'";
    		
    		ResultSet st = conn.createStatement().executeQuery(sql);
    		while(st.next()) {
    			String title = st.getString("b.title");
    			String startDate = st.getString("bo.startDate");
    			String endDate = st.getString("bo.endDate");
    			mixCustomer.add(new MixCustomer(title,startDate,endDate));
    		}
    		
    		Named.setCellValueFactory(new PropertyValueFactory<>("Title"));
    		StartDate.setCellValueFactory(new PropertyValueFactory<>("StartDate"));
    		EndDate.setCellValueFactory(new PropertyValueFactory<>("EndDate"));
    		
    		table3.setItems(mixCustomer);
    		
    		mixCustomer=FXCollections.observableArrayList();
    	}
    	
    	catch(Exception ex) {
    		JOptionPane.showMessageDialog(null, ex);
    	}
    	
    }
    

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
    }
}
