package application;

import java.io.IOException;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class CustomerSignUp implements Initializable{
	    @FXML
	    private TextField idText;

	    @FXML
	    private TextField passText;

	    @FXML
	    private TextField nameText;

	    @FXML
	    private TextField addText;

	    @FXML
	    private TextField pText;

	
	   public void signup() {
		   try {

				Connection conn = Main.getConnection();
				PreparedStatement pst;

				String sql = "insert into Customer (cid,passward,c_name,address,hasPremuim) values(?,?,?,?,? )";

				pst = conn.prepareStatement(sql);
				
					pst.setString(1, idText.getText());
					pst.setString(2, passText.getText());
					pst.setString(3, nameText.getText());
					pst.setString(4, addText.getText());
					pst.setString(5, pText.getText());
					pst.execute();
					JOptionPane.showMessageDialog(null, "Customer Add succes");
				

			
				conn.close();

			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e);
			}
	   }
	   public void back(ActionEvent event) {
		   AnchorPane pane;
			try {
				pane = (AnchorPane) FXMLLoader.load(getClass().getResource("MainInterface.fxml"));
				Scene scene = new Scene(pane);
				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(scene);
				window.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }
	   
	   
		public void moreInfo(ActionEvent event) {
	    	AnchorPane pane;
			try {
				pane = (AnchorPane) FXMLLoader.load(getClass().getResource("aboutus.fxml"));
				Scene scene = new Scene(pane);
				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(scene);
				window.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

}
