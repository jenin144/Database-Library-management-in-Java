package application;


import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class MainInterface implements Initializable{

	 @FXML
	    private TextField OnClicktype;
	 @FXML 
	     TextField userNameField;
     @FXML
	    private PasswordField passwordTF;
     
     
        static String IDText_LogSign;
        
        
  
        
      // onMouseClicked     
        
    	public void logToEmployee() {
            updatIDText_LogSignLog("Emolyee");
            System.out.println("Employee login selected");
    	}

    	public void logToCustomer() {
    		updatIDText_LogSignLog("Customer");
            System.out.println("Customer login selected");
    	}

    	public void logToManger() {
    		updatIDText_LogSignLog("Manager");
            System.out.println("Manager login selected");
    	}
    	
        
    	   private void updatIDText_LogSignLog(String text) {
    	        OnClicktype.setText(text);
    	    }   
    	
    	
    	   public void logIn(ActionEvent event) throws Exception {
    	        String userType = OnClicktype.getText();
    	        switch (userType) {
    	            case "Emolyee":
    	                handleEmployeeLogin(event);
    	                break;
    	            case "Customer":
    	            	handleCustomerLogin(event);
    	                break;
    	            case "Manager":
    	            	handleManagerLogin(event);
    	                break;
    	            default:
    	                showAlert("Error", "Invalid user type");
    	                break;
    	        }
    	    }
    	   
    	   

   
    	   private void handleManagerLogin(ActionEvent event) throws Exception  {
				
				Connection conn = Main.getConnection();
				String sql = "select * from Employee where eid= '" + userNameField.getText() + "'";
				IDText_LogSign=userNameField.getText();
				Statement st = conn.createStatement();
				ResultSet result = st.executeQuery(sql);
				if (result.next()) {
					String userName = result.getString("eid");
					String pass = result.getString("passward");
				    boolean isManager = result.getBoolean("isManager");
				    if (isManager) {

					if (userNameField.getText().equals(userName) && passwordTF.getText().equals(pass)) {
						
						    Pane pane;
							pane = (Pane) FXMLLoader.load(getClass().getResource("Manager.fxml"));
							Scene scene = new Scene(pane);
							Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
							window.setScene(scene);
							window.show();
						 

					} else {
						JOptionPane.showMessageDialog(null, " Incorrect UserName or Password :)");
					}
					
					
				    }				
				    else	JOptionPane.showMessageDialog(null, "Just Manager Allowed to enter!");


				} else {
					JOptionPane.showMessageDialog(null, "You are Not the Manager");
				}
    		   
    		   
    		   
			}
    	   
     	   private void handleEmployeeLogin(ActionEvent event) throws Exception  {
				
  				Connection conn = Main.getConnection();
				String sql = "select * from Employee where eid= '" + userNameField.getText() + "'";
				
				 IDText_LogSign=userNameField.getText();
				
				Statement st = conn.createStatement();
				ResultSet result = st.executeQuery(sql);
				if (result.next()) {
					String userName = result.getString("eid");
					String pass = result.getString("passward");

					if (userNameField.getText().equals(userName) && passwordTF.getText().equals(pass)) {
						AnchorPane pane;
						pane = (AnchorPane) FXMLLoader.load(getClass().getResource("EmployeeScene.fxml"));
						Scene scene = new Scene(pane);
						Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
						window.setScene(scene);
						window.show();

					} else {
						JOptionPane.showMessageDialog(null, "Incorrect UserName or Password :)");
					}

				} else {
					JOptionPane.showMessageDialog(null, "You are not an employee");
				}
    		   
    		   
    		   
    			}
 
    	   
    	   private void handleCustomerLogin(ActionEvent event) throws Exception { 
    		   
 
    		   
				Connection conn = Main.getConnection();
				String sql = "select * from Customer where cid= '" + userNameField.getText() + "'";
				
				 IDText_LogSign=userNameField.getText();
				 
				Statement st = conn.createStatement();
				ResultSet result = st.executeQuery(sql);
				if (result.next()) {
					String userName = result.getString("cid");
					String pass = result.getString("passward");

					if (userNameField.getText().equals(userName) && passwordTF.getText().equals(pass)) {
						AnchorPane pane;
						pane = (AnchorPane) FXMLLoader.load(getClass().getResource("Customer.fxml"));
						Scene scene = new Scene(pane);
						Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
						window.setScene(scene);
						window.show();

					} else {
						JOptionPane.showMessageDialog(null, "Incorrect UserName or Password :)");
					}

				} else {
					JOptionPane.showMessageDialog(null, "Welcome!, is this your first time? Sign up first");
				}
    		   
    		   
    		   
    		   
    	       
    	}
    	   
    	   public void signUp(ActionEvent event) {
   	        String userType = OnClicktype.getText();
   	        switch (userType) {
   	            case "Customer":
   	                loadSignUpScene(event, "CustomerSignUp.fxml");
   	                break;
   	            case "Emolyee":
   	                showAlert("Restricted Access", "Only managers can register employees!!");
   	                break;
   	            case "Manager":
   	                showAlert("Restricted Access", "You cannot signup as manager!!");
   	                break;
   	            default:
   	                showAlert("Error", "Invalid user type for signup");
   	                break;
   	        }
   	    }

   	    private void loadSignUpScene(ActionEvent event, String fxmlFile) {
   	        try {
   	            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
   	            Scene scene = new Scene(loader.load());
   	            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
   	            window.setScene(scene);
   	            window.show();
   	        } catch (IOException e) {
   	            e.printStackTrace(); 
   	        }
   	    
   	}
			


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}

	 private void showAlert(String title, String message) {
	        Alert alert = new Alert(Alert.AlertType.INFORMATION);
	        alert.setTitle(title);
	        alert.setContentText(message);
	        alert.show();
	    }
	 
	 
		public void back(ActionEvent event) {
	    	AnchorPane pane;
			try {
				pane = (AnchorPane) FXMLLoader.load(getClass().getResource("MainInterface.fxml"));
				Scene scene = new Scene(pane);
				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(scene);
				window.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	 
		public void moreInfo(ActionEvent event) {
	    	AnchorPane pane;
			try {
				pane = (AnchorPane) FXMLLoader.load(getClass().getResource("aboutus.fxml"));
				Scene scene = new Scene(pane);
				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(scene);
				window.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	 
	
}
