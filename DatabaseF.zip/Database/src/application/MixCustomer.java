package application;

public class MixCustomer {
private String Title;
private String StartDate;
private String EndDate;
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public String getStartDate() {
	return StartDate;
}
public void setStartDate(String startDate) {
	StartDate = startDate;
}
public String getEndDate() {
	return EndDate;
}
public void setEndDate(String endDate) {
	EndDate = endDate;
}
public MixCustomer() {
	super();
}
public MixCustomer(String title, String startDate, String endDate) {
	super();
	Title = title;
	StartDate = startDate;
	EndDate = endDate;
}
}
