package application;

import java.util.Date;

public class Employee {
	private String eid;
	private String passward;
	private String firstName;
	private String lastName;
	private Date DOB;
	private String address;
	private String phoneNumber;
	private String salary;
	
    // Constructor for the Employee class

	public Employee(String eid, String passward, String firstName, String lastName, Date DOB, String address,
			String phoneNumber, String salary) {
		super();
		this.eid = eid;
		this.passward = passward;
		this.firstName = firstName;
		this.lastName = lastName;
		this.DOB = DOB;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.salary = salary;
	}
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getPassward() {
		return passward;
	}
	public void setPassward(String passward) {
		this.passward = passward;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	
   
	
    
	
	

}
