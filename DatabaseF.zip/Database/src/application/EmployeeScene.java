package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class EmployeeScene implements Initializable{
	public void employeeScene(ActionEvent event) {
		AnchorPane pane;
		try {
			pane = (AnchorPane) FXMLLoader.load(getClass().getResource("Employee.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   
		
	}
	public void employeeAccount(ActionEvent event) {
		AnchorPane pane;
		try {
			pane = (AnchorPane) FXMLLoader.load(getClass().getResource("EmployeeAccount.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
	   }

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

}
