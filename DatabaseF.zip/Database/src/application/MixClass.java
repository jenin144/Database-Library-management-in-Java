package application;

public class MixClass { //multiple table (title-> book , c_nme->customer , start/end date -> borrow )
	private String c_name;
	private String bid;
	private String startDate;
	private String endDate;
	
	public MixClass(String c_name, String bid, String startDate, String endDate) {
		super();
		this.c_name = c_name;
		this.bid = bid;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getTitle() {
		return bid;
	}

	public void setbid(String title) {
		this.bid = title;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
	
	

}
