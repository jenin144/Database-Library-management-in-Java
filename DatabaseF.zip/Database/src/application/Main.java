


package application;
	
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.fxml.FXMLLoader;

public class Main extends Application {
	
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	
	@Override
	public void start(Stage primaryStage) {
		try {
			AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("MainInterface.fxml"));
			Scene scene = new Scene(root,900,500);
		//	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
	        primaryStage.setTitle(" Library DataBase ");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static Connection getConnection() throws SQLException {
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/BookDBMS?autoReconnect=true&useSSL=false", "root", "1200540");
		return connection;
	}
	
		
	
	public static ObservableList<Book> getDataBook() {
		Connection conn;
		ObservableList<Book> oblist = FXCollections.observableArrayList();
		try {
			conn = Main.getConnection();
			ResultSet st = conn.createStatement().executeQuery("select * from Book");
			while (st.next()) {
				oblist.add(new Book(st.getString("bid"), st.getString("author"), st.getString("title"),
						st.getString("edition"), st.getString("releaseYear"), st.getString("sectionname"),
						st.getString("standardPremuim"), st.getString("NumOFcopiesAvilable")));

			}
			JOptionPane.showMessageDialog(null, "Connection  Succeffully Stablished");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return oblist;
	}
	

	public static ObservableList<Customer> getDataCustomer() {
		Connection conn;
		ObservableList<Customer> oblist = FXCollections.observableArrayList();
		try {
			conn = Main.getConnection();
			ResultSet st = conn.createStatement().executeQuery("select * from Customer");
			while (st.next()) {
				oblist.add(new Customer(st.getString("cid"), st.getString("passward"), st.getString("c_name"),
						st.getString("address"), st.getString("hasPremuim"),st.getString("debt")));

			}
			JOptionPane.showMessageDialog(null, "Connection  Succeffully Stablished");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return oblist;
	}
	public static ObservableList<Employee> getDataEmployee() {
		Connection conn;
		ObservableList<Employee> oblist = FXCollections.observableArrayList();
		try {
			conn = Main.getConnection();
			ResultSet st = conn.createStatement().executeQuery("select * from Employee");
			while (st.next()) {
				oblist.add(new Employee(st.getString("cid"), st.getString("passward"), st.getString("firstName"),
						st.getString("lastName"), st.getDate("DOB"), st.getString("address"),st.getString("phoneNumber"),st.getString("salary")));

			}
			JOptionPane.showMessageDialog(null, "Connection  Succeffully Stablished");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return oblist;
	}

	public static ObservableList<Borrow> getDataBorrow() {
		Connection conn;
		ObservableList<Borrow> oblist = FXCollections.observableArrayList();
		try {
			conn = Main.getConnection();
			ResultSet st = conn.createStatement().executeQuery("select * from Borrow");
			while (st.next()) {
				oblist.add(new Borrow(st.getString("cid"), st.getString("bid"), st.getString("startDate")));

			}
			JOptionPane.showMessageDialog(null, "Connection  Succeffully Stablished");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return oblist;
	}
	
	
}
