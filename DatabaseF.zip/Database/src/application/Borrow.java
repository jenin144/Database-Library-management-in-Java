package application;

public class Borrow {
       
       private String cid;
       private String bid;
       private String startDate;
       
       
       
	public Borrow(String cid, String bid, String startDate) {
		super();
		
		this.cid = cid;
		this.bid = bid;
		this.startDate = startDate;
	}
	
	
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
       
       
	
}
