package application;
import java.util.Date;

public class Manager {
    private int eid;
    private String mfirstname;
    private String mlastname;
    private double salary;
    private String phonenum;
    private Date DOB;
    private String address;
    private String passward;

    public Manager(int eid, String passward, String mfirstname, String mlastname, Date DOB, String add,String phonenum, double salary) {
        super();
        this.eid = eid;
        this.mfirstname = mfirstname;
        this.mlastname = mlastname;
        this.salary = salary;
        this.passward=passward;
        this.address=add;
        this.DOB=DOB;
        this.phonenum=phonenum;
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String getMlastname() {
        return mlastname;
    }

    public void setMlastname(String mlastname) {
        this.mlastname = mlastname;
    }

    public String getMfirstname() {
        return mfirstname;
    }

    public void setMfirstname(String mfirstname) {
        this.mfirstname = mfirstname;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getPhonenum() {
        return phonenum;
    }

    public void setPhonenum(String phonenum) {
        this.phonenum = phonenum;
    }

    public Date getDOB() {
        return DOB;
    }

    public void setDOB(Date DOB) {
        this.DOB = DOB;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassward() {
        return passward;
    }

    public void setPassward(String passward) {
        this.passward = passward;
    }
}

