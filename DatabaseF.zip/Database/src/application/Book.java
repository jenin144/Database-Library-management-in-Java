package application;

public class Book {
	private String bid;
	private String author;
	private String title;
	private String edition;
	private String releaseYear;
	private String sectionname;
	private String standardPremuim;
	private String NumOFcopiesAvilable;
	private int NumberOFborrow;
	
	
	public Book(String bid, String author, String title, String edition, String releaseYear, String sectionname,
			String standardPremuim, String NumOFcopiesAvilable ) {
		super();
		this.bid = bid;
		this.author = author;
		this.title = title;
		this.edition = edition;
		this.releaseYear = releaseYear;
		this.sectionname = sectionname;
		this.standardPremuim = standardPremuim;
		this.NumOFcopiesAvilable = NumOFcopiesAvilable;
		
		

	}
	
	
	  public Book(String bid, String title, int NumberOFborrow) {
	        this.bid = bid;
	        this.title = title;
	        this.NumberOFborrow = NumberOFborrow;
	    }
	

    public int getNumberOfBorrow() {
        return NumberOFborrow;
    }
    
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEdition() {
		return edition;
	}
	public void setEdition(String edition) {
		this.edition = edition;
	}
	
	public String getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(String releaseYear) {
		this.releaseYear = releaseYear;
	}
	public String getSectionname() {
		return sectionname;
	}
	public void setSectionname(String sectionname) {
		this.sectionname = sectionname;
	}
	public String getStandardPremuim() {
		return standardPremuim;
	}
	public void setStandardPremuim(String standardPremuim) {
		this.standardPremuim = standardPremuim;
	}
	public String getNumOFcopiesAvilable() {
		return NumOFcopiesAvilable;
	}
	public void setNumOFcopiesAvilable(String NumOFcopiesAvilable) {
		this.NumOFcopiesAvilable = NumOFcopiesAvilable;
	}
	
	
	

}
