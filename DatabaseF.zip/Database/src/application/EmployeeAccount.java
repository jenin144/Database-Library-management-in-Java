package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javax.swing.JOptionPane;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class EmployeeAccount implements Initializable{
	  @FXML
	    private TextField IDTextFiled;

	    @FXML
	    private TextField PasswodTF;

	    @FXML
	    private TextField FistNameTF;

	    @FXML
	    private TextField LastNameTF;

	    @FXML
	    private DatePicker DobTF;

	    @FXML
	    private TextField AdressTF;

	    @FXML
	    private TextField PhoneNUMTF;

	    @FXML
	    private TextField SalaryTF;
   

    
    public void back(ActionEvent event) {
    	AnchorPane pane;
		try {
			pane = (AnchorPane) FXMLLoader.load(getClass().getResource("EmployeeScene.fxml"));
			Scene scene = new Scene(pane);
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(scene);
			window.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    public void EditEmpInfo() {
    	try {
			Connection conn = Main.getConnection();
			//IDTextFiled.setEditable(false);
			//SalaryTF.setEditable(false);
			String DOB = String.valueOf(DobTF.getValue());
			String ID = IDTextFiled.getText();
			String salary = SalaryTF.getText();
			String password = PasswodTF.getText();
			String firstname = FistNameTF.getText();
			String phonenumber = PhoneNUMTF.getText();
			String lastname = LastNameTF.getText();
			String Adress = AdressTF.getText();
			PreparedStatement pforediting;
			String sql = "update Employee set eid ='" + ID + "',passward ='" + password + "',firstName ='" + firstname
					+ "',lastName ='" + lastname+ "',DOB ='" + DOB +"',address ='" + Adress+
					"',phoneNumber ='" + phonenumber+"',salary ='" + salary + "'where eid='" + ID + "'";
			pforediting = conn.prepareStatement(sql);
			pforediting.execute();
			// Show a confirmation message
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Edit Successful");
			alert.setHeaderText(null);
			alert.setContentText("Done Editing!");
			alert.showAndWait();
			System.out.println("**Done Editng**");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e);
		}
    }
    
    
	  


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		try {
			Connection conn=Main.getConnection();
			String s=MainInterface.IDText_LogSign;
			String sql="select * from Employee where eid='"+s+"'";
			Statement st = conn.createStatement();
			ResultSet autofill = st.executeQuery(sql);
			if(autofill.next()) {
				IDTextFiled.setText(autofill.getString("eid"));
				PasswodTF.setText(autofill.getString("passward"));
				FistNameTF.setText(autofill.getString("firstName"));
				LastNameTF.setText(autofill.getString("lastName"));
				AdressTF.setText(autofill.getString("address"));
				PhoneNUMTF.setText(autofill.getString("phoneNumber"));
				DobTF.setPromptText(autofill.getString("DOB"));
				SalaryTF.setText(autofill.getString("salary"));
			
			}
		    
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e);
		}
		
	}

}
